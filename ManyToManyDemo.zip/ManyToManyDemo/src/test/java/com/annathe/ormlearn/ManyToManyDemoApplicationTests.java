package com.annathe.ormlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToManyDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
