package com.annathe.ormlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.repository.StudentRepository;

@SpringBootApplication
public class ManyToManyDemoApplication {
	
	private static StudentRepository studentRepository;

	public static void main(String[] args) {
		
		
		ApplicationContext context = SpringApplication.run(ManyToManyDemoApplication.class, args);
	
		studentRepository = context.getBean(StudentRepository.class);
		
		//testretrieveStudentandTeachers();
		testInsertStudentAndTeachers();
		
	}
	
	
	public static void testretrieveStudentandTeachers() {
		
		studentRepository.retrieveStudentandTeachers();
			
			
		}
	
	
	public static void testInsertStudentAndTeachers() {
		
		studentRepository.insertStudentAndCourses();
		
	}

}
