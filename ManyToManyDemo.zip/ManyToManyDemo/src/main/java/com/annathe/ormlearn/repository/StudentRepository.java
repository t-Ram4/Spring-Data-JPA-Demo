package com.annathe.ormlearn.repository;
import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Student;
import com.annathe.ormlearn.model.Teacher;

@Transactional
@Repository
public class StudentRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public void retrieveStudentandTeachers() {
		
		Student student =em.find(Student.class, 1);
		
		System.out.println("Student name: "+student.getName());
		
		System.out.println("Teachers: "+student.getTeachers());
		
	}
	
	
	public void insertStudentAndCourses() {
		
		Student student = new Student(2,"Uday");
		
		Teacher teacher = new Teacher(101,"Guru");
		
		em.persist(student);
		em.persist(teacher);
		
		student.addTeacher(teacher);
		teacher.addStudent(student);
		
		em.persist(student);
		
	}

}
