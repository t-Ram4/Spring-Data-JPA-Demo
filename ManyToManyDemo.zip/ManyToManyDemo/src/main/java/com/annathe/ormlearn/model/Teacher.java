
package com.annathe.ormlearn.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Teacher")
public class Teacher {


	//for Hibernate 4.3.x Users
	@Id
	@Column(name="id")	
	private int id;
		
	@Column(name="name")
	private String name;
	
	@ManyToMany(mappedBy="teachers")
	private List <Student> students = new ArrayList();	
	
	public List getStudents() {
		return students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}

	public Teacher() {}
	
	public Teacher(int id, String name) {
		
		this.id = id;
		this.name = name;
				
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	
	
}












