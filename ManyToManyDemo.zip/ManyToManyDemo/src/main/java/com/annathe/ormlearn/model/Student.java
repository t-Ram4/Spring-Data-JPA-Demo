package com.annathe.ormlearn.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class Student {
	
	
	@Id
	@Column(name="id")	
	private int id;
	
	@Column(name="name")
	private String name;
	
	@ManyToMany
	@JoinTable(name="Student_Teacher",joinColumns=@JoinColumn(name="Student_ID"),inverseJoinColumns=@JoinColumn(name="Teacher_ID"))
	private List<Teacher> teachers = new ArrayList();
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Teacher> getTeachers() {
		return teachers;
	}


	public void addTeacher(Teacher teacher) {
		this.teachers.add(teacher);
	}

	public void removeTeacher(Teacher teacher) {
		
		this.teachers.remove(teacher);
		
	}

	public Student(int id,String name ) {
		
		this.id = id;
		this.name = name;
			
	}

	
	public Student() {
		
		
	}

	
}
