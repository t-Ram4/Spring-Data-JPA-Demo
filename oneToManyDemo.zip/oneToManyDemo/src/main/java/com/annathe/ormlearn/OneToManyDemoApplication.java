package com.annathe.ormlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.repository.BookRepository;


@SpringBootApplication
public class OneToManyDemoApplication {
	
	private static BookRepository bookRepository;

	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(OneToManyDemoApplication.class, args);
	
		bookRepository = context.getBean(BookRepository.class); 
		
		testaveBooksForPublisher();
	}


public static void testaveBooksForPublisher() {
		
	bookRepository.saveBooksForPublisher();
		
		
	}
	
	
}
