package com.annathe.ormlearn.repository;
import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Book;
import com.annathe.ormlearn.model.Publisher;

@Transactional
@Repository
public class BookRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public void saveBooksForPublisher() {
		
		Publisher publisher = em.find(Publisher.class, 1);
		
		Book book1 =new Book(101,"Electrical Machines");
		Book book2 = new Book(102,"AWS Architect");
		
		publisher.addBook(book1);
		book1.setPublisher(publisher);
		
		publisher.addBook(book2);
		book2.setPublisher(publisher);
		
		
		em.persist(book1);
		
		em.persist(book2);
		
	}

}
