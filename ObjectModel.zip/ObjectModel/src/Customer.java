
public class Customer {
	
	private String name;
	
	private SBAccount sbAccount;
	
	
	public Customer(String name, SBAccount sbAcc) {
		
		this.name = name;
		this.sbAccount = sbAcc;
		
	}

}
