
public class EMICalculator implements ICalculator{
	
	public  float calculateEMI(LoanAccount loanAc) {
		
		float emi = loanAc.getPrincipal() * loanAc.getInterestRate() * 1;
		
		return emi;
		
	}
	
	
	public void calculate() {
		
		System.out.println("It is a dummy implemetation");
	}

}
