import java.util.List;

public class Doctor {
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private List<Patient> myPateients;

	public List<Patient> getMyPateients() {
		return myPateients;
	}

	public void setMyPateients(List<Patient> myPateients) {
		this.myPateients = myPateients;
	}
	

}
