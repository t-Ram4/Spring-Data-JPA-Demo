import java.util.ArrayList;
import java.util.List;

public class Main {
	
	public static void main(String arg[]) {
		
		SBAccount sbAcc = new SBAccount();
		
		sbAcc.setAccountNumber(123);
		
		sbAcc.setInterestRate(6f);
				
		
		Customer customer = new Customer("Ram", sbAcc);
		
		LoanAccount loanAc = new LoanAccount();
		
		loanAc.setAccountNumber(12345);
		loanAc.setPrincipal(100000f);
		loanAc.setInterestRate(10.5f);
		
		EMICalculator calculator = new EMICalculator();
		float calculatedEMI = calculator.calculateEMI(loanAc);
		
		System.out.println("EMI "+ calculatedEMI);
		
		
		Address address1 = new Address();
		
		address1.setCity("Chennai");
		address1.setStreetName("first street");
		address1.setState("TamilNadu");
		
		Patient patient1 =new Patient();
		
		patient1.setName("Ravi");
		patient1.setAddress(address1);
		
		
		Address address2 = new Address();
		
		address2.setCity("Chennai");
		address2.setStreetName("Second street");
		address2.setState("TamilNadu");
		
		Patient patient2 =new Patient();
		
		patient2.setName("Ravindran");
		patient2.setAddress(address2);
		
		Doctor  doctor = new Doctor();
		
		doctor.setName("Kumar");
		
		ArrayList<Patient> myPatients = new ArrayList<Patient>();
		
		myPatients.add(patient1);
		myPatients.add(patient2);
		
		doctor.setMyPateients(myPatients);
		
		Department department = new Department();
		
		department.setName("Cardio");
		
		ArrayList<Doctor> doctors = new ArrayList<Doctor>();
		doctors.add(doctor);
		
		department.setDoctors(doctors);
		
		Hospital hospital = new  Hospital();
		
		hospital.setName("Stanly Hospital");
		
		ArrayList<Department> departments = new ArrayList<Department>();
		
		departments.add(department);
		
		hospital.setDepartments(departments);
		
		
		//**********************************************
		
		List<Department> myDepartments = hospital.getDepartments();
		
		for(Department d:myDepartments) {
			
			List<Doctor> myDoctors = d.getDoctors();
			
			for(Doctor dr:myDoctors) {
				
				List<Patient> pts = dr.getMyPateients();
				
				for(Patient p:pts) {
					
					System.out.println("Patient Name: "+p.getName());
					System.out.println("Patient State: "+p.getAddress().getState());
					System.out.println("Patient City: "+p.getAddress().getCity());
					System.out.println("Patient Street: "+p.getAddress().getStreetName());
				}
			}
		}
		
		
		
		
	}

}
