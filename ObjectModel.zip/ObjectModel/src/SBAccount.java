
public class SBAccount extends Account{
	
	private float interestRate;

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}
	
	
	


}
