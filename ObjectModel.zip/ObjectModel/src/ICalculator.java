
public interface ICalculator {
	
	public  float calculateEMI(LoanAccount loanAc);

}
