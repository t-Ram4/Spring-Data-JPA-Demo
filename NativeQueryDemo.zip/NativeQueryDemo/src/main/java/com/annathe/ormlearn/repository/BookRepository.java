package com.annathe.ormlearn.repository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Book;
import com.annathe.ormlearn.model.Publisher;



@Transactional
@Repository
public class BookRepository {
	
	
	@Autowired
	private EntityManager em;
	
	
	
	public void  getAllBooksUsingNativeQuery() {
		
		Query query = em.createNativeQuery("Select * from Book",Book.class);
		
		List resultList = query.getResultList();
		System.out.println("list of books: "+resultList);
	}
	
public void getAllBooksUsingNativeQueryAndParameter() {
		
		Query query = em.createNativeQuery("Select * from Book where book_id=?",Book.class);
		
		query.setParameter(1, 800);
		
	Book book = (Book)query.getSingleResult();
		System.out.println("Book with corresponds to 800: "+book.getName());
	}





}
