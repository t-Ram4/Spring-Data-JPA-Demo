package com.annathe.ormlearn;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.model.Book;
import com.annathe.ormlearn.repository.BookRepository;
import com.annathe.ormlearn.repository.MyRepository;

@SpringBootApplication
public class NativeQueryDemoApplication {
	
	private static BookRepository bookRepository;
	private static MyRepository myRepository;

	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(NativeQueryDemoApplication.class, args);
		bookRepository = context.getBean(BookRepository.class);
		myRepository = context.getBean(MyRepository.class);
		//testGetAllBooksUsingNativeQuery();
		//testGetAllBooksUsingNativeQueryAndParameter();
		
		testGetAllBooks();
	}

	
	public static void testGetAllBooksUsingNativeQuery() {
		
		bookRepository.getAllBooksUsingNativeQuery();
	}
	
	public static void testGetAllBooksUsingNativeQueryAndParameter() {
		
		bookRepository.getAllBooksUsingNativeQueryAndParameter();
	}
	
	public static void testGetAllBooks() {
		
		List<Book> books = myRepository.getAllBooks();
		System.out.println("Books retrieved using naitive query: "+books);
	}
}
