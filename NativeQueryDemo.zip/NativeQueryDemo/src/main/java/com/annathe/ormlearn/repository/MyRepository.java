package com.annathe.ormlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.annathe.ormlearn.model.Book;


public interface MyRepository extends JpaRepository<Book, Integer>{
	
	@Query(value="SELECT * FROM Book", nativeQuery = true) 
	List<Book> getAllBooks(); 


}
