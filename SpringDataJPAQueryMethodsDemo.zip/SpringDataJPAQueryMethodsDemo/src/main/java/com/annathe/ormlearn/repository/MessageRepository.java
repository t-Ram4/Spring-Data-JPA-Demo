package com.annathe.ormlearn.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.annathe.ormlearn.model.Message;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long>{
	
	
	 @Query("SELECT m FROM Message m where m.text like 'Hello%'")
	    public List<Message> findMessagesWithHello();	

}
