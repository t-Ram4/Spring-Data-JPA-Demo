package com.annathe.ormlearn;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.model.Message;
import com.annathe.ormlearn.repository.MessageRepository;

@SpringBootApplication
public class SpringDataJpaQueryMethodsDemoApplication {
	
	private static MessageRepository messageRepository; 
	public static void main(String[] args) {
		
		ApplicationContext context =SpringApplication.run(SpringDataJpaQueryMethodsDemoApplication.class, args);
		messageRepository = context.getBean(MessageRepository.class); 
		
		findMessagesWithHello();
	
	}

 public static void findMessagesWithHello() {
	 
	 System.out.println("inside findmessageswithHello() method");
		
		List<Message> messages =messageRepository.findMessagesWithHello();
		
		for(Message m: messages) {
		
		System.out.println("Message name: "+m.getText());
		
		}
		
		
	}




}
