package com.annathe.SpringDataJPAQueryMethodsDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaQueryMethodsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
