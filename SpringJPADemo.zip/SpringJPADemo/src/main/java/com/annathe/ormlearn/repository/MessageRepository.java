package com.annathe.ormlearn.repository;
import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.annathe.ormlearn.model.Message;

@Repository
public class MessageRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public Message findById(Long id) {
		
		return em.find(Message.class, id);
		
	}

}
