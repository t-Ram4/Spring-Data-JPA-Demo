package com.annathe.ormlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.model.Message;
import com.annathe.ormlearn.service.MessageService;

@SpringBootApplication
public class SpringJpaDemoApplication {

	private static MessageService messageService; 
	
	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(SpringJpaDemoApplication.class, args);
		
		messageService = context.getBean(MessageService.class); 
		
		testFindById(3l);
		
	}

	public static void testFindById(Long id) {
		
		
		Message message = messageService.findNyId(id);
		
		System.out.println("Message name: "+message.getText());
		
		
		
		
	}


}
