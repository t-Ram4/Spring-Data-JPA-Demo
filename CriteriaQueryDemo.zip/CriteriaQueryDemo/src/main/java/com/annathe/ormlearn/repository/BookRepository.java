package com.annathe.ormlearn.repository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Book;



@Transactional
@Repository
public class BookRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public void selectAllBooksWithCriteriaQuery() {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
		
		CriteriaQuery<Book> cq = cb.createQuery(Book.class);
		
		Root<Book> bookRoot = cq.from(Book.class);
		
		TypedQuery<Book> query = em.createQuery(cq.select(bookRoot));
		
		List<Book> resultList = query.getResultList();
		
		System.out.println("List of books: "+resultList);
	}

}
