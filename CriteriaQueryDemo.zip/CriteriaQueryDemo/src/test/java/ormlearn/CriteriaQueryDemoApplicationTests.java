package ormlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CriteriaQueryDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
