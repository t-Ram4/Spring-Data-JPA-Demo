package com.annathe.ormlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.repository.BookRepository;

@SpringBootApplication
public class HqlDemoApplication {
	
	private static BookRepository bookRepository;

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(HqlDemoApplication.class, args);
		bookRepository = context.getBean(BookRepository.class);
		
		//testGetAllBooksUsingHQL();
		
		//testGetAllBooksUsingHQLwithTypedQuery();
		
		testGetAllBooksUsingHQLwithNamedQuery();
		
	}

	
	public static void testGetAllBooksUsingHQL() {
		
		bookRepository.getAllBooksUsingHQL();
		
	}
	
	public static void testGetAllBooksUsingHQLwithTypedQuery() {
		
		bookRepository.getAllBooksUsingHQLwithTypedQuery();
	}
	
	public static void testGetAllBooksUsingHQLwithNamedQuery() {
		
		bookRepository.getAllBooksUsingHQLwithNamedQuery();
	}
	
}
