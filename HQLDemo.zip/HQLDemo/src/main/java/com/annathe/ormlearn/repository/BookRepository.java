package com.annathe.ormlearn.repository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Book;
import com.annathe.ormlearn.model.Publisher;



@Transactional
@Repository
public class BookRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public void saveBooksForPublisher() {
		
		Publisher publisher = new Publisher(606,"Manning publications");
		em.persist(publisher);
		
		Book book1 =new Book(802,"Talks with Ramana maharishi");
		Book book2 = new Book(803,"Search in secret Egypt");
		
		publisher.addBook(book1);
		book1.setPublisher(publisher);
		
		publisher.addBook(book2);
		book2.setPublisher(publisher);
		
		
		em.persist(book1);
		
		em.persist(book2);
		
	}
	
	public void  getAllBooksUsingHQL() {
		
		Query query = em.createQuery("Select b from Book b");
		
		List resultList = query.getResultList();
		System.out.println("list of books: "+resultList);
	}
	
public void getAllBooksUsingHQLwithTypedQuery() {
		
		TypedQuery<Book> query = em.createQuery("Select b from Book b",Book.class);
		
		List resultList = query.getResultList();
		System.out.println("list of books: "+resultList);
	}

public void getAllBooksUsingHQLwithNamedQuery() {
	
	TypedQuery<Book> query = em.createNamedQuery("get_All_Books",Book.class);
	
	List<Book> resultList = query.getResultList();
	
	for(Book b:resultList)
	System.out.println("books: "+b.getName());
}



}
