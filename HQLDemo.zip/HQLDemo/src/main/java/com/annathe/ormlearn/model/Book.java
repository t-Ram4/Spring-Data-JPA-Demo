
package com.annathe.ormlearn.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Book")
@NamedQuery(name="get_All_Books", query="Select b from Book b")
public class Book {


	//for Hibernate 4.3.x Users
	@Id
	@Column(name="book_id")	
	private int id;
		
	@Column(name="name")
	private String name;
	
	@ManyToOne
	private Publisher publisher;	
	
	public Publisher getPublisher() {
		return publisher;
	}

	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}

	public Book() {}
	
	public Book(int id, String name) {
		
		this.id = id;
		this.name = name;
				
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	
	
}












