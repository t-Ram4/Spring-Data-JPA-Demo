package com.annathe.ormlearn.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Publisher")
public class Publisher {
	
	
	@Id
	@Column(name="id ")	
	private int id;
	
	@Column(name="name")
	private String name;
	
	@OneToMany(mappedBy="publisher")
	private List<Book> books = new ArrayList();
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Book> getBook() {
		return books;
	}


	public void addBook(Book book) {
		this.books.add(book);
	}

	public void removeBook(Book book) {
		
		this.books.remove(book);
		
	}

	public Publisher(int id,String name ) {
		
		this.id = id;
		this.name = name;
			
	}

	
	public Publisher() {
		
		
	}

	
}
