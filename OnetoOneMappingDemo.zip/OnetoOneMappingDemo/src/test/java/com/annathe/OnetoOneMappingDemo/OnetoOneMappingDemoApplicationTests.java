package com.annathe.OnetoOneMappingDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoOneMappingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
