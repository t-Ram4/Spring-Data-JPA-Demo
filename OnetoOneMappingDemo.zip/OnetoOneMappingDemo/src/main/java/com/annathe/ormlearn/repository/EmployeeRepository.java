package com.annathe.ormlearn.repository;
import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.annathe.ormlearn.model.Address;
import com.annathe.ormlearn.model.Employee;

@Transactional
@Repository
public class EmployeeRepository {
	
	
	@Autowired
	private EntityManager em;
	
	public void saveEmployeeWithAddress() {
		
		Address address = new Address();
		
		address.setAddressId(1);
		address.setStreet("First cross street");
		address.setCity("Chennai");
		address.setState("Tamil Nadu");
		address.setCountry("India");
		
		em.persist(address);
		
		Employee employee = new Employee();
		employee.setEmployeeId(100);
		employee.setFirstName("Ramasubramanian");
		employee.setLastName("Balasubramanian");
		
		employee.setAddress(address);
		
		em.persist(employee);
		
	}

}
