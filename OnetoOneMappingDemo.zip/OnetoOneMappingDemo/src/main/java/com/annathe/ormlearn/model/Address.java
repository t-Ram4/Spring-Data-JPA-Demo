
package com.annathe.ormlearn.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Address")
public class Address {


	//for Hibernate 4.3.x Users
	@Id
	@Column(name="id")	
	private int addressId;
		
	@Column(name="street")
	private String street;
	
	@Column(name="city")	
	private String city;
	
	@Column(name="state")	
	private String state;
	
	@Column(name="country")	
	private String country;
	
		
	public int getAddressId() {
		return addressId;
	}


	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public Address() {}
	
	public Address(int addressId, String street, String city,String state, String country) {
		
		this.addressId = addressId;
		this.street = street;
		this.state = state;
		this.country = country;
		
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}
	
	
	
}












