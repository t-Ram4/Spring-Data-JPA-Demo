package com.annathe.SpringDataJPADMLDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpadmlDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
