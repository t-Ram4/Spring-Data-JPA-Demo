package com.cognizant.ormlearn.model;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
public class Country1 {

private String code;
private String name;


public Country1(String code,String name)
{
	this.code=code;
	this.name=name;
}


public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

@Override
public String toString() {
	return "Country [code=" + code + ", name=" + name + "]";
}



public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}


// getters and setters

// toString()

}